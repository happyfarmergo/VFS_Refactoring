# VFS_Refactoring
DesignPattern Course Project
---  

会议小结
=======  
    1.吕酱有一个小目标，关于界面，去找一找添加标签页的控件，实现，操作界面统一化，简洁化。  
    2.吕酱有一个小小目标，研究一下排列问题，标记这个做不做呢~~~（参照finder的标记模式）
